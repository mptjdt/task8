using UnityEngine;
using ī��;

public class GameStart : MonoBehaviour
{

    void Start()
    {
        GameManager.Main();
    }
}
